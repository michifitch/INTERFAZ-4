package biblioteca;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class mundi {

    public static void main(String[] args) {
        new MundialApp();
    }
}

class Equipo {

    private String nombre;
    private String entrenador;
    private ArrayList<Jugador> jugadores;

    public Equipo(String nombre, String entrenador) {
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.jugadores = new ArrayList<>();
    }

    public void agregarJugador(Jugador jugador) {
        jugadores.add(jugador);
    }

    public String getNombre() {
        return nombre;
    }

    public String mostrarInfo() {
        return "Equipo: " + nombre + "\nEntrenador: " + entrenador + "\nNúmero de jugadores: " + jugadores.size();
    }
}

class Jugador {

    private String nombre;
    private int edad;
    private String posicion;

    public Jugador(String nombre, int edad, String posicion) {
        this.nombre = nombre;
        this.edad = edad;
        this.posicion = posicion;
    }

    public String mostrarInfo() {
        return "Jugador: " + nombre + "\nEdad: " + edad + "\nPosición: " + posicion;
    }
}

class Partido {

    private Equipo equipoLocal;
    private Equipo equipoVisitante;
    private int[] resultado;

    public Partido(Equipo equipoLocal, Equipo equipoVisitante) {
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.resultado = null;
    }

    public void jugarPartido(int[] resultado) {
        this.resultado = resultado;
    }

    public String mostrarResultado() {
        if (resultado != null) {
            return "Resultado: " + equipoLocal.getNombre() + " " + resultado[0] + " - " + resultado[1] + " " + equipoVisitante.getNombre();
        } else {
            return "Partido no jugado todavía.";
        }
    }
}

class Grupo {

    private String nombre;
    private ArrayList<Equipo> equipos;

    public Grupo(String nombre) {
        this.nombre = nombre;
        this.equipos = new ArrayList<>();
    }

    public void agregarEquipo(Equipo equipo) {
        equipos.add(equipo);
    }

    public ArrayList<Equipo> getEquipos() {
        return equipos;
    }

    public String mostrarInfo() {
        String info = "Grupo: " + nombre + "\nEquipos en el grupo:";
        for (Equipo equipo : equipos) {
            info += "\n- " + equipo.getNombre();
        }
        return info;
    }
}

class Estadio {

    private String nombre;
    private String ciudad;
    private int capacidad;

    public Estadio(String nombre, String ciudad, int capacidad) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.capacidad = capacidad;
    }

    public String mostrarInfo() {
        return "Estadio: " + nombre + "\nCiudad: " + ciudad + "\nCapacidad: " + capacidad + " personas";
    }
}

class Mundial {

    private ArrayList<Grupo> grupos;
    private ArrayList<Estadio> estadios;

    public Mundial() {
        this.grupos = new ArrayList<>();
        this.estadios = new ArrayList<>();
    }

    public void registrarGrupo(Grupo grupo) {
        grupos.add(grupo);
    }

    public void registrarEstadio(Estadio estadio) {
        estadios.add(estadio);
    }

    public ArrayList<Grupo> getGrupos() {
        return grupos;
    }

    public String generarFixture() {
        return "Se han registrado " + grupos.size() + " grupos en el Mundial.";
    }
}

class MundialApp extends JFrame {

    private Mundial mundial;
    private JTextField entryEquipo;
    private JTextField entryEntrenador;
    private JTextField entryJugador;
    private JTextField entryEdad;
    private JTextField entryPosicion;
    private JTextField entryGrupo;
    private JTextField entryEstadio;
    private JTextField entryCiudad;
    private JTextField entryCapacidad;
    private JLabel labelInfo;

    public MundialApp() {
        mundial = new Mundial();

        setTitle("Sistema de Gestión Mundial de Fútbol");
        setLayout(new GridLayout(15, 2));

        add(new JLabel("Nombre del Equipo:"));
        entryEquipo = new JTextField();
        add(entryEquipo);

        add(new JLabel("Nombre del Entrenador:"));
        entryEntrenador = new JTextField();
        add(entryEntrenador);

        JButton btnRegistrarEquipo = new JButton("Registrar Equipo");
        btnRegistrarEquipo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrarEquipo();
            }
        });
        add(btnRegistrarEquipo);

        add(new JLabel("Nombre del Jugador:"));
        entryJugador = new JTextField();
        add(entryJugador);

        add(new JLabel("Edad del Jugador:"));
        entryEdad = new JTextField();
        add(entryEdad);

        add(new JLabel("Posición del Jugador:"));
        entryPosicion = new JTextField();
        add(entryPosicion);

        JButton btnAgregarJugador = new JButton("Agregar Jugador");
        btnAgregarJugador.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                agregarJugador();
            }
        });
        add(btnAgregarJugador);

        add(new JLabel("Nombre del Grupo:"));
        entryGrupo = new JTextField();
        add(entryGrupo);

        JButton btnRegistrarGrupo = new JButton("Registrar Grupo");
        btnRegistrarGrupo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrarGrupo();
            }
        });
        add(btnRegistrarGrupo);

        add(new JLabel("Nombre del Estadio:"));
        entryEstadio = new JTextField();
        add(entryEstadio);

        add(new JLabel("Ciudad del Estadio:"));
        entryCiudad = new JTextField();
        add(entryCiudad);

        add(new JLabel("Capacidad del Estadio:"));
        entryCapacidad = new JTextField();
        add(entryCapacidad);

        JButton btnRegistrarEstadio = new JButton("Registrar Estadio");
        btnRegistrarEstadio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrarEstadio();
            }
        });
        add(btnRegistrarEstadio);

        JButton btnGenerarFixture = new JButton("Generar Fixture");
        btnGenerarFixture.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                generarFixture();
            }
        });
        add(btnGenerarFixture);

        labelInfo = new JLabel();
        add(labelInfo);

        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void registrarEquipo() {
        String nombreEquipo = entryEquipo.getText();
        String entrenadorEquipo = entryEntrenador.getText();
        Equipo equipo = new Equipo(nombreEquipo, entrenadorEquipo);
        Grupo grupo = new Grupo(nombreEquipo);
        grupo.agregarEquipo(equipo);
        mundial.registrarGrupo(grupo);
        labelInfo.setText("Equipo registrado:\n" + equipo.mostrarInfo());
    }

    private void agregarJugador() {
        String nombreJugador = entryJugador.getText();
        int edadJugador = Integer.parseInt(entryEdad.getText());
        String posicionJugador = entryPosicion.getText();
        Jugador jugador = new Jugador(nombreJugador, edadJugador, posicionJugador);

        if (mundial.getGrupos().size() > 0) {
            Grupo ultimoGrupo = mundial.getGrupos().get(mundial.getGrupos().size() - 1);
            if (ultimoGrupo.getEquipos().size() > 0) {
                Equipo ultimoEquipo = ultimoGrupo.getEquipos().get(ultimoGrupo.getEquipos().size() - 1);
                ultimoEquipo.agregarJugador(jugador);
                labelInfo.setText("Jugador agregado:\n" + jugador.mostrarInfo());
            } else {
                JOptionPane.showMessageDialog(this, "No hay equipos registrados aún.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "No hay equipos registrados aún.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void registrarGrupo() {
        String nombreGrupo = entryGrupo.getText();
        Grupo grupo = new Grupo(nombreGrupo);
        mundial.registrarGrupo(grupo);
        labelInfo.setText("Grupo registrado:\n" + grupo.mostrarInfo());
    }

    private void registrarEstadio() {
        String nombreEstadio = entryEstadio.getText();
        String ciudadEstadio = entryCiudad.getText();
        int capacidadEstadio = Integer.parseInt(entryCapacidad.getText());
        Estadio estadio = new Estadio(nombreEstadio, ciudadEstadio, capacidadEstadio);
        mundial.registrarEstadio(estadio);
        labelInfo.setText("Estadio registrado:\n" + estadio.mostrarInfo());
    }

    private void generarFixture() {
        String fixtureInfo = mundial.generarFixture();
        labelInfo.setText("Fixture generado:\n" + fixtureInfo);
    }

}
